<!DOCTYPE html>
<html>
 <head>
  <meta charset="utf-8">
  <title>賣家介面</title>
 </head>
 <body>
  <p align="center"><b><i><font size="7">我是賣家</font></i></b></p>
  <input type ="button" onclick="history.back()" value="返回"></input>
  <div align="center" style="position:relative;top:10px">
  <input type="button" name="register" value="賣家資訊" onclick="window.location.href='seller_information.php'"/>  
</div>

<div align="center" style="position:relative;top:20px">
  <input type="button" name="register" value="新增產品" onclick="window.location.href='seller_newproduct.php'"/>  
</div>

<div align="center" style="position:relative;top:30px">
  <input type="button" name="register" value="現有產品" onclick="window.location.href='seller_currentProduct.php'"/>  
</div>

<div align="center" style="position:relative;top:40px">
  <input type="button" name="register" value="交易紀錄" onclick="window.location.href='seller_transaction.php'"/>  
</div>

<div align="center" style="position:relative;top:50px">
  <input type="button" name="register" value="開始競標" onclick="window.location.href='seller_trading.php'"/>  
</div>
 
 </body>
</html> 
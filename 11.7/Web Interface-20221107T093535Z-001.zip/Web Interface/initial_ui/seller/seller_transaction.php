<!DOCTYPE html>
<html>
 <head>
  <meta charset="utf-8">
  <title>即期競標系統</title>
 </head>
 <body>
  <p align="center"><b><i><font size="7">交易紀錄</font></i></b></p>
  <input type ="button" onclick="history.back()" value="返回"></input>
  
 
 
 </body>
</html>